package code.project.common;

public class PageResponse {
    //페이징 응답 DTO
}
