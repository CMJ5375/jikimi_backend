package code.project.common;

public class ApiResponse {
    //공통 응답 래퍼
}
