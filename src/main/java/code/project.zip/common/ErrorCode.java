package code.project.common;

public class ErrorCode {
    //에러 코드 정의
}
