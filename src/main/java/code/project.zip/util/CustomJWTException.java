package code.project.util;

public class CustomJWTException extends RuntimeException{

    public CustomJWTException (String msg) {
        super(msg);
    }
}
