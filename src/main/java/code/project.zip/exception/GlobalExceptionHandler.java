package code.project.exception;

public class GlobalExceptionHandler {
//전역 예외 처리 (@RestControllerAdvice)
}
