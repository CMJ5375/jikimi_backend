package code.project.exception;

public class BusinessException {
//커스텀 비즈니스 예외
}
