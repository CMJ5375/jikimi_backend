package code.project.controller;

public class SocialController {
}
