package code.project.config;

public class SwaggerConfig {
    //API가 DB안거치고 바로 가게하는 부붑ㄴ Swagger API란 방법이 있다함 자세히는 아직 모름
}
