package code.project.config;

public class WebConfig{
 //Cors,Json 설정
}
