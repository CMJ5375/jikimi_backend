package code.project.domain;

public enum Bizday {
    MON, TUE, WED, THU, FRI, SAT, SUN
}
