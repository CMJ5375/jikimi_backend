package code.project.domain;

public enum FacilityType {
    HOSPITAL, PHARMACY
}
