package code.project.domain;

public enum LocalType {
    LOCAL, GOOGLE, KAKAO
}
